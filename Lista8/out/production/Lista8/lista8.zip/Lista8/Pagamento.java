package Lista8;

public interface Pagamento {
    public String getTipoPagamento();
}
