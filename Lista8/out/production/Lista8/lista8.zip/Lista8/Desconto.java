package Lista8;

public interface Desconto {
    public double getDescontoSilver();
    public double getDescontoLight();
    public double getDescontoPlus();
    public double getDescontoCartao();
}

