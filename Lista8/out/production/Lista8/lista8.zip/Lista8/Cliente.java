package Lista8;
import java.time.LocalDate;
import java.time.Period;

public class Cliente extends Sistema{

    private int idade;
    String tipoCliente;
    Compra compra;
    double valorTotal;
    String tipoPagamento;

    public Cliente(String nome, String cpf, String email, String telefone, LocalDate nascimento, String endereco, String tipoPagamento) {
        super(nome, cpf, email, telefone, nascimento, endereco);
    }

    public void setCompra(Compra compra){
        this.compra = compra;
    }

    public double getValorTotal(){
        valorTotal += compra.getValorCompra();
        return valorTotal;
    }

    public int getIdade (){
        this.idade = Period.between(nascimento, LocalDate.now()).getYears();
        return idade;
    }
    public void setIdade(int idade){
        this.idade = idade;
    }

    public String getTipoCliente(){
        int idade = this.idade;
        if(idade < 60 && compra.getValorBase() >= 500){
            tipoCliente = "silver";
        }
        else if(idade >= 60 && compra.getValorBase() <= 500){
            tipoCliente = "light";
        }
        else if(idade >= 60 && compra.getValorBase() >= 500){
            tipoCliente = "plus";
        }
        else {
            tipoCliente = "normal";
        }
        return tipoCliente;
    }

    public String getTipoPagamento(){
        return tipoPagamento;
    }

    public void setTipoPagamento(String tipoDePagamento){
        this.tipoPagamento = tipoDePagamento;
    }
}
