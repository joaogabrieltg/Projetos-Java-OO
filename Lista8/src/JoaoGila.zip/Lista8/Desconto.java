package Lista8;

public interface Desconto {
    double getDescontoSilver();
    double getDescontoLight();
    double getDescontoPlus();
    double getDescontoCartao();
}

