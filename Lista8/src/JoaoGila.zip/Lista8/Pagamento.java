package Lista8;

public interface Pagamento {
    String getTipoPagamento();
}
