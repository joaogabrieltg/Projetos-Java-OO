package Lista9;

public class placaInvalidaException extends Exception{
    public placaInvalidaException(){
        super("Placa fora do padrao");
    }
}
