package Lista9;

public class chassiInvalidoException extends Exception{
    public chassiInvalidoException(){
        super("Codigo do chassi esta fora do padrao");
    }
}