package Lista7;
import java.time.LocalDate;

public class Motorista {

    private String nome;
    private String cpf;
    private String cnh;
    private LocalDate dataDeNascimento;
    private LocalDate dataDeEntrada;
    private Veiculo veiculoCadastrado;
    private boolean vinculoEmpresarial = false;

    public Motorista(String nome, String cpf, String cnh, LocalDate dataDeNascimento, LocalDate dataDeEntrada, Veiculo veiculoCadastrado, boolean vinculoEmpresarial) {
        this.nome = nome;
        this.cpf = cpf;
        this.cnh = cnh;
        this.dataDeNascimento = dataDeNascimento;
        this.dataDeEntrada = dataDeEntrada;
        this.veiculoCadastrado = veiculoCadastrado;
        this.vinculoEmpresarial = vinculoEmpresarial;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCnh() {
        return cnh;
    }

    public void setCnh(String cnh) {
        this.cnh = cnh;
    }

    public LocalDate getDataDeNascimento() {
        return dataDeNascimento;
    }

    public void setDataDeNascimento(LocalDate dataDeNascimento) {
        this.dataDeNascimento = dataDeNascimento;
    }

    public LocalDate getDataDeEntrada() {
        return dataDeEntrada;
    }

    public void setDataDeEntrada(LocalDate dataDeEntrada) {
        this.dataDeEntrada = dataDeEntrada;
    }

    public Veiculo getVeiculoCadastrado() {
        return veiculoCadastrado;
    }

    public void setVeiculoCadastrado(Veiculo veiculoCadastrado) {
        this.veiculoCadastrado = veiculoCadastrado;
    }

    public boolean isVinculoEmpresarial() {
        return vinculoEmpresarial;
    }

    public void setVinculoEmpresarial(boolean vinculoEmpresarial) {
        this.vinculoEmpresarial = vinculoEmpresarial;
    }

    public double calcularRepasse(double valorDaCorrida) {
        return (valorDaCorrida * 0.2);
    }

    public void printarCaracterísticas(){
        String vinculo;
        if (isVinculoEmpresarial()){
            vinculo = "Sim";
        }
        else{
            vinculo = "Nao";
        }
        System.out.println("\nnome: "+getNome() +
                "\ncpf: "+getCpf()+
                "\ncnh: "+getCnh()+
                "\ndata de nascimento: "+getDataDeNascimento()+
                "\ndata de entrada: "+getDataDeEntrada()+
                "\nnome do veiculo: "+getVeiculoCadastrado().getModelo()+
                "\nvinculo empresarial? "+ vinculo);
    }
}