package Lista7;
import java.time.LocalDate;

public class CarraraTaxis {
    public static void main(String[] args){

        String nome = "Agostinho Carrara";
        String cpf = "5318008";
        String cnh = "8008135";
        LocalDate nascimento = LocalDate.of(1968, 4,22);
        LocalDate dataDeEntrada = LocalDate.of(2001, 3,29);
        String placa = "CPR-8253";
        String chassi = "1AB234CD56E789123";
        int ano = 1959;
        String modelo = "Volkswagen Santana";
        String cor = "Amarelo";
        boolean vinculoEmpresarial = true;
        double valorDaCorrida = 100;
        int passageiros = 4;
        Veiculo veiculoCadastrado = new Veiculo(placa, chassi, ano, modelo, cor);

        Motorista normal = new Motorista(nome, cpf, cnh, nascimento, dataDeEntrada, veiculoCadastrado, false);
        Motorista diamante = new MotoristaDiamante(nome, cpf, cnh, nascimento, dataDeEntrada, veiculoCadastrado, false);
        Motorista enterprise = new MotoristaEnterprise(nome, cpf, cnh, nascimento, dataDeEntrada, veiculoCadastrado, passageiros, vinculoEmpresarial);

        System.out.println("normal: " + normal.calcularRepasse(valorDaCorrida));
        System.out.println("diamante: " + diamante.calcularRepasse(valorDaCorrida));
        System.out.println("enterprise: " + enterprise.calcularRepasse(valorDaCorrida)+
                " para " + passageiros + " passageiros");
        normal.printarCaracterísticas();
        diamante.printarCaracterísticas();
        enterprise.printarCaracterísticas();
    }
}

/**QUESTAO 2**/
/* O polimorfismo e um termo utilizado em orientacao a objetos que indica que um mesmo elemento do codigo seja usado varias vezes
de maneiras distintas, como utilizado na questao o @override, que significa que o metodo calcularRepasse foi utilizado novamente
mas com funcoes e comandos diferentes, retirando assim, a necessidade de reescrita com outros nomes, pois apenas sobrescrever
e o suficiente.
Diferentemente do Override, o Overload ao inves de utilizar o mesmo metodo com funcoes diferentes, ele permite criar metodos
diferentes com o mesmo nome, permitindo que parametros diferentes sejam recebidos. Nesse caso, nao se fez necessario.
*/